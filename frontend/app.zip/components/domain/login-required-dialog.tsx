// components/domain/login-required-dialog.tsx
"use client";

import { useRouter } from "next/navigation";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface LoginRequiredDialogProps {
  open: boolean;
  onClose: () => void;
}

export function LoginRequiredDialog({ open, onClose }: LoginRequiredDialogProps) {
  const router = useRouter();

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>로그인이 필요해요</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground">
          이 기능은 로그인 후에 이용할 수 있어요.
        </p>
        <div className="grid grid-cols-2 gap-2">
          <Button
            variant="outline"
            onClick={() => {
              onClose();
              router.push("/auth/signup/terms");
            }}
          >
            회원가입
          </Button>
          <Button
            onClick={() => {
              onClose();
              router.push("/auth/login?next=/cart");
            }}
          >
            로그인
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}