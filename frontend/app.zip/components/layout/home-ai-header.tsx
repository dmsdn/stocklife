"use client";

import Image from "next/image";
import Link from "next/link";
import { useState } from "react";

import { AiChatPanel } from "@/components/ai/ai-chat-panel";

const MOCK_UNREAD_COUNT = 2;

interface HomeAiHeaderProps {
  active?: "home" | "ai";
  onAiChat?: () => void;
}

export function HomeAiHeader({
  active = "home",
  onAiChat,
}: HomeAiHeaderProps) {
  const [showAiPanel, setShowAiPanel] = useState(false);

  const pageContext =
    active === "home"
      ? `
현재 사용자는 쇼핑 홈 화면을 보고 있습니다.

현재 화면의 주요 내용:
- 나의 쇼핑 상태
- 보유 포인트: 2,840P
- 이번 달 절약: 18,400원
- AI 활용: 12회
- 이번 주 생필품 구매 시기가 가까워짐
- 예상 장보기 금액: 약 27,800원
- 추천 상품
- AI가 발견한 할인 상품
- 나의 장바구니
- AI가 기억하고 있는 지난 장보기 계획
`
      : `
현재 사용자는 AI 쇼핑 화면을 보고 있습니다.
`;

  const handleAiClick = () => {
    if (onAiChat) {
      onAiChat();
      return;
    }

    setShowAiPanel(true);
  };

  return (
    <>
      <header className="flex h-16 w-full items-center justify-between">
        {/* ─────────────────────
            왼쪽 : 쇼핑 로고 + AI Chat
        ───────────────────── */}
        <div className="flex items-center gap-3">
          <Link
            href="/"
            aria-label="홈 화면으로 이동"
            className="shrink-0 transition-opacity hover:opacity-70"
          >
            <Image
              src="/icons/logo-shopping.svg"
              alt="쇼핑"
              width={120}
              height={40}
              priority
            />
          </Link>

          <span className="text-muted-foreground">|</span>

          <button
            type="button"
            onClick={handleAiClick}
            aria-label="AI Chat 열기"
            className="shrink-0 transition-opacity hover:opacity-70"
          >
            <Image
              src="/icons/logo-ai.svg"
              alt="AI Chat"
              width={120}
              height={40}
              priority
            />
          </button>
        </div>

        {/* ─────────────────────
            오른쪽 : 웹 네비게이션
            홈 아이콘은 제외
        ───────────────────── */}
        <nav
          className="flex items-center gap-1"
          aria-label="주요 메뉴"
        >
          <Link
            href="/search"
            aria-label="검색"
            title="검색"
            className="flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <SearchIcon />
          </Link>

          <Link
            href="/saved"
            aria-label="저장"
            title="저장"
            className="flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <HeartIcon />
          </Link>

          <Link
            href="/scan"
            aria-label="스캔"
            title="스캔"
            className="flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <BarcodeIcon />
          </Link>

          <Link
            href="/mypage"
            aria-label="마이페이지"
            title="마이페이지"
            className="flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <UserIcon />
          </Link>

          {/* 알림 */}
          <Link
            href="/notifications"
            aria-label="알림"
            title="알림"
            className="relative ml-1 flex h-10 w-10 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <BellIcon />

            {MOCK_UNREAD_COUNT > 0 && (
              <span className="absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger px-0.5 text-[10px] font-semibold leading-none text-primary-foreground">
                {MOCK_UNREAD_COUNT}
              </span>
            )}
          </Link>
        </nav>
      </header>

      {/* 기존 AI Chat 연결 유지 */}
      {!onAiChat && (
        <AiChatPanel
          open={showAiPanel}
          onClose={() => setShowAiPanel(false)}
          pageContext={pageContext}
        />
      )}
    </>
  );
}

/* 아이콘 */

function SearchIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-4-4" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M20.8 8.9c0 5.2-8.8 10.1-8.8 10.1S3.2 14.1 3.2 8.9A4.6 4.6 0 0 1 12 6.2a4.6 4.6 0 0 1 8.8 2.7Z" />
    </svg>
  );
}

function BarcodeIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M3 5v14" />
      <path d="M7 5v14" />
      <path d="M10 5v14" />
      <path d="M14 5v14" />
      <path d="M17 5v14" />
      <path d="M21 5v14" />
    </svg>
  );
}

function UserIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c0-4.2 3.6-7 8-7s8 2.8 8 7" />
    </svg>
  );
}

function BellIcon() {
  return (
    <svg
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9" />
      <path d="M10 21h4" />
    </svg>
  );
}