"use client";

import { BottomTabBar } from "./bottom-tab-bar";
import { AiPanelProvider } from "./ai-panel-context";
import { AiPanel } from "./ai-panel";
import { HomeAiHeader } from "./home-ai-header";

export function AppShell({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AiPanelProvider>
      <div className="mx-auto flex min-h-full w-full flex-col md:max-w-[1440px]">
        {/* =========================================
            WEB HEADER
            - 웹에서만 표시
            - 모든 페이지 공통
            - 스크롤 시 같이 사라짐
            ========================================= */}
        <div className="fixed inset-x-0 top-0 z-[100] hidden md:block">
          <div className="mx-auto max-w-[1440px] border-b border-border bg-background/95 backdrop-blur">
            <div className="px-8">
              <HomeAiHeader />
            </div>
          </div>
        </div>

        {/* =========================================
            CONTENT
            웹에서는 고정 헤더 높이만큼 위쪽 여백
            모바일에서는 기존 구조 그대로
            ========================================= */}
        <div className="flex flex-1 md:pt-16">
          <main className="flex-1 pb-[calc(4rem+env(safe-area-inset-bottom))] md:pb-0">
            {children}
          </main>

          <AiPanel />
        </div>

        {/* 모바일 하단탭 */}
        <BottomTabBar />
      </div>
    </AiPanelProvider>
  );
}