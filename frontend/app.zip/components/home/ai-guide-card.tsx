import { ArrowRight } from "lucide-react";

type AiGuideCardProps = {
  icon: React.ReactNode;
  title: string;
  description: string;
  button: string;
  onClick: () => void;
};

export function AiGuideCard({
  icon,
  title,
  description,
  button,
  onClick,
}: AiGuideCardProps) {
  return (
    <div className="w-[78vw] max-w-[280px] shrink-0 rounded-sm border border-border p-4">
      <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-muted">
        {icon}
      </div>

      <h3 className="mt-4 whitespace-pre-line text-md font-semibold leading-5">
        {title}
      </h3>

      <p className="mt-2 h-10 text-sm leading-4 text-muted-foreground">
        {description}
      </p>

      <button
        type="button"
        onClick={onClick}
        className="mt-4 flex items-center gap-1 text-sm font-medium"
      >
        {button}
        <ArrowRight size={14} />
      </button>
    </div>
  );
}
