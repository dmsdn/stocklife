import { SectionTitle } from "./section-title";

import type { HomeProduct } from "@/lib/home-data";

type DiscoverProductsProps = {
  products: HomeProduct[];
  onProductClick: (productId: number) => void;
};

export function DiscoverProducts({
  products,
  onProductClick,
}: DiscoverProductsProps) {
  return (
    <section className="w-full pt-10">
      <div className="px-4 sm:px-6 lg:px-8">
        <SectionTitle eyebrow="DISCOVER" title="발견해보세요" action="더보기" />
      </div>

      <div className="w-full overflow-x-auto scrollbar-hide">
        <div className="flex w-max gap-3 px-4 pb-1 sm:px-6 lg:px-8">
          {products.map((product) => (
            <button
              key={product.id}
              type="button"
              onClick={() => onProductClick(product.id)}
              className="w-[140px] shrink-0 text-left"
            >
              <div className="relative aspect-square overflow-hidden rounded-sm bg-muted">
                <img
                  src={product.image}
                  alt={product.name}
                  className="h-full w-full object-cover"
                />
              </div>

              <p className="mt-2 truncate text-md font-medium">{product.name}</p>

              <p className="mt-1 text-md font-semibold">
                {product.price.toLocaleString("ko-KR")}원
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
