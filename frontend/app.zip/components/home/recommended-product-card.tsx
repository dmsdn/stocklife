import { Heart, Sparkles } from "lucide-react";

import type { RecommendedProduct } from "@/lib/home-data";

type RecommendedProductCardProps = {
  product: RecommendedProduct;
  onProductClick: () => void;
  onSave: () => void;
};

export function RecommendedProductCard({
  product,
  onProductClick,
  onSave,
}: RecommendedProductCardProps) {
  return (
    <div className="w-full min-w-0">
      <div className="relative">
        <button
          type="button"
          onClick={onProductClick}
          className="block w-full text-left"
        >
          <div className="relative aspect-square overflow-hidden rounded-sm bg-muted">
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover"
            />

            <div className="absolute left-2 top-2 max-w-[calc(100%-40px)] truncate rounded-sm bg-background/90 px-1.5 py-1 text-xs font-medium">
              {product.badge}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={onSave}
          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-background/90"
          aria-label={`${product.name} 장바구니 저장`}
        >
          <Heart size={15} />
        </button>
      </div>

      <button
        type="button"
        onClick={onProductClick}
        className="mt-2 block w-full text-left"
      >
        <p className="truncate text-md font-medium">{product.name}</p>

        <p className="mt-1 text-md font-semibold">
          {product.price.toLocaleString("ko-KR")}원
        </p>
      </button>

      <div className="mt-2 rounded-sm bg-muted/60 p-2">
        <div className="flex items-center gap-1">
          <Sparkles size={11} className="shrink-0" />
          <span className="truncate text-sm font-medium">
            왜 추천했을까요?
          </span>
        </div>

        <p className="mt-1 line-clamp-2 text-sm leading-4 text-muted-foreground">
          {product.reason}
        </p>
      </div>
    </div>
  );
}
