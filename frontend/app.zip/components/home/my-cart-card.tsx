import { ChevronRight, ShoppingCart } from "lucide-react";

type MyCartCardProps = {
  onClick: () => void;
};

export function MyCartCard({ onClick }: MyCartCardProps) {
  return (
    <section className="w-full px-4 pt-8 sm:px-6 lg:px-8">
      <div className="mb-3 flex items-end justify-between gap-2">
        <div className="min-w-0">
          <p className="text-xs font-medium tracking-wide text-muted-foreground">
            MY SHOPPING
          </p>
          <h2 className="mt-1 text-lg font-semibold">나의 장바구니</h2>
        </div>

        <span className="shrink-0 text-sm text-muted-foreground">전체보기</span>
      </div>

      <button
        type="button"
        onClick={onClick}
        className="w-full rounded-sm border border-border p-4 text-left"
      >
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-sm bg-muted">
            <ShoppingCart size={18} />
          </div>

          <div className="min-w-0 flex-1">
            <p className="text-md font-semibold">이번주 장보기</p>

            <p className="mt-1 text-sm text-muted-foreground">
              상품 7개 · 예상 38,200원
            </p>
          </div>

          <ChevronRight
            size={16}
            className="shrink-0 text-muted-foreground"
          />
        </div>

        <div className="mt-4">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">준비 진행률</span>
            <span className="text-sm font-medium">70%</span>
          </div>

          <div className="mt-2 h-1.5 overflow-hidden rounded-sm bg-muted">
            <div className="h-full w-[70%] rounded-sm bg-foreground" />
          </div>
        </div>
      </button>
    </section>
  );
}
