"use client";

import { Heart, Sparkles } from "lucide-react";

import {
  formatPrice,
  type RecommendedProduct,
} from "@/lib/home-data";
import { SectionTitle } from "./section-title";

type RecommendedProductsProps = {
  products: RecommendedProduct[];
  onProductClick: (productId: number) => void;
  onSave: (product: RecommendedProduct) => void;
  onMore: () => void;
};

export function RecommendedProducts({
  products,
  onProductClick,
  onSave,
  onMore,
}: RecommendedProductsProps) {
  return (
    <section className="w-full px-4 pt-8 sm:px-6 lg:px-8">
      <SectionTitle
        eyebrow="FOR YOU"
        title="브리핑에 맞춰 추천해요"
      />

      <div className="grid grid-cols-2 gap-x-3 gap-y-5">
        {products.map((product) => (
          <RecommendedProductCard
            key={product.id}
            product={product}
            onProductClick={() =>
              onProductClick(product.id)
            }
            onSave={() => onSave(product)}
          />
        ))}
      </div>

      <button
        type="button"
        onClick={onMore}
        className="mt-6 flex h-10 w-full items-center justify-center gap-1 rounded-sm border border-border text-sm font-medium"
      >
        추천 상품 더보기
        <span aria-hidden>›</span>
      </button>
    </section>
  );
}

function RecommendedProductCard({
  product,
  onProductClick,
  onSave,
}: {
  product: RecommendedProduct;
  onProductClick: () => void;
  onSave: () => void;
}) {
  return (
    <div className="w-full min-w-0">
      <div className="relative">
        <button
          type="button"
          onClick={onProductClick}
          className="block w-full text-left"
        >
          <div className="relative aspect-square overflow-hidden rounded-sm bg-muted">
            <img
              src={product.image}
              alt={product.name}
              className="h-full w-full object-cover"
            />

            <div className="absolute left-2 top-2 max-w-[calc(100%-40px)] truncate rounded-sm bg-background/90 px-1.5 py-1 text-xs font-medium">
              {product.badge}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={onSave}
          className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-full bg-background/90"
          aria-label={`${product.name} 장바구니 저장`}
        >
          <Heart size={13} />
        </button>
      </div>

      <button
        type="button"
        onClick={onProductClick}
        className="mt-2 block w-full text-left"
      >
        <p className="truncate text-base font-medium">
          {product.name}
        </p>

        <p className="mt-1 text-base font-semibold">
          {formatPrice(product.price)}
        </p>
      </button>

      <div className="mt-2 rounded-sm bg-muted/60 p-2">
        <div className="flex items-center gap-1">
          <Sparkles
            size={11}
            className="shrink-0"
          />

          <span className="truncate text-xs font-medium">
            왜 추천했을까요?
          </span>
        </div>

        <p className="mt-1 line-clamp-2 text-xs leading-4 text-muted-foreground">
          {product.reason}
        </p>
      </div>
    </div>
  );
}