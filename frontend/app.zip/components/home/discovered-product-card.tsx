import { Sparkles, TrendingDown } from "lucide-react";

import type { DiscoveredProduct } from "@/lib/home-data";

type DiscoveredProductCardProps = {
  product: DiscoveredProduct;
  onClick: () => void;
};

export function DiscoveredProductCard({
  product,
  onClick,
}: DiscoveredProductCardProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full rounded-sm border border-border p-3.5 text-left"
    >
      <div className="flex items-start gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="rounded-sm bg-muted px-2 py-1 text-xs font-medium">
              {product.discount} OFF
            </span>

            <span className="text-sm text-muted-foreground">AI 발견</span>
          </div>

          <p className="mt-2 text-md font-medium">{product.name}</p>

          <div className="mt-1 flex items-center gap-2">
            <span className="text-md font-semibold">
              {product.price.toLocaleString("ko-KR")}원
            </span>

            <span className="text-sm text-muted-foreground line-through">
              {product.originalPrice.toLocaleString("ko-KR")}원
            </span>
          </div>
        </div>

        <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-sm bg-muted">
          <TrendingDown size={15} />
        </div>
      </div>

      <div className="mt-3 flex items-start gap-1.5">
        <Sparkles
          size={12}
          className="mt-0.5 shrink-0 text-muted-foreground"
        />

        <p className="text-sm leading-4 text-muted-foreground">
          {product.reason}
        </p>
      </div>
    </button>
  );
}
